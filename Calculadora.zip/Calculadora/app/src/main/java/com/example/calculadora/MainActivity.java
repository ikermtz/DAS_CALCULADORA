package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText et1;
    private EditText et2;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et1 = (EditText)findViewById(R.id.numero1);
        et2 = (EditText)findViewById(R.id.numero2);
        tv = (TextView)findViewById(R.id.resultado);
    }


    //Este metodo hace la suma
    public void Sumar(View view){
        String a = et1.getText().toString();
        String b = et2.getText().toString();

        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);

        int suma = num2 + num1;

        String resultado = String.valueOf(suma);
        tv.setText(resultado);
    }
}